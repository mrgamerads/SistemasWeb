﻿
using LivroCaixa2023.Classes;
using LivroCaixa2023.Tabelas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LIvroCaixa2023.Paginas
{
    public partial class CadastroUuarios : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["usuario"] == null)
            {
                Response.Redirect("index.aspx",false);
                return;
            }
            tabusers.Text = Usuario.montaTabela("Usuários Cadastrados",Usuario.lista);
            inicializa(); 
        }

        private void inicializa()
        {
            lbTitulo.Text = "Cadastro de Usuários - Livro Caixa";
            lbLogin.Text = "Login";
            lbNome.Text = "Nome";
            lbUsu.Text = "Usu";
            lbAdm.Text = "Adm";
            lbCpf.Text = "Cpf";
            lbPerfil.Text = "Perfil";
        }

        protected void btOk_Click(object sender, EventArgs e)
        {
            lbMensagem.Text = string.Empty;

            if (!rbAdm.Checked && !rbUsu.Checked)
            {
                lbMensagem.Text = "Selecione o perfil do usuário!";
                return;
            }

            if (txNome.Text.Trim() == string.Empty)
            {
                lbMensagem.Text = "Digite o nome do usuário!";
                return;
            }

            if (txLogin.Text.Trim() == string.Empty)
            {
                lbMensagem.Text = "Digite o login do usuário!";
                return;
            }

            if (!validaCPF(txCpf.Text))
            {
                lbMensagem.Text = "CPF digitado inválido!";
                return;
            }

            if (Usuario.lista != null)
            {
                foreach (Usuario usu in Usuario.lista)
                {
                    if (txLogin.Text == usu.login)
                    {
                        lbMensagem.Text = "Login digitado já cadastrado!";
                        return;
                    }

                    if (txCpf.Text == usu.cpf)
                    {
                        lbMensagem.Text = "CPF digitado já cadastrado!";
                        return;
                    }
                }
            }

            

            Usuario u = new Usuario(txLogin.Text, txCpf.Text, txNome.Text, 
                rbAdm.Checked ? 'A' : 'U',
                txCpf.Text);

            Usuario.lista.Add(u);
            Serializa.save(Usuario.lista);

            tabusers.Text = Usuario.montaTabela("Usuários Cadastrados", Usuario.lista);

            lbMensagem.Text = "Usuário cadastrado com sucesso!";           
        }

        public bool validaCPF(string cpf)
        {
            int[] multiplicador1 = new int[9] { 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicador2 = new int[10] { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            string tempCpf;
            string digito;
            int soma;
            int resto;

            cpf = cpf.Trim();
            cpf = cpf.Replace(".", "").Replace("-", "").Replace("/", "").Replace("-", " ");

            if (cpf.Length != 11)
                return false;

            tempCpf = cpf.Substring(0, 9);
            soma = 0;

            for (int i = 0; i < 9; i++)
            {
                soma += int.Parse(tempCpf[i].ToString()) * multiplicador1[i];
            }

            resto = soma % 11;

            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;

            digito = resto.ToString();

            tempCpf = tempCpf + digito;

            soma = 0;

            for (int i = 0; i < 10; i++)
                soma += int.Parse(tempCpf[i].ToString()) * multiplicador2[i];

            resto = soma % 11;

            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;

            digito = digito + resto.ToString();

            return cpf.EndsWith(digito);
        }
    }
}