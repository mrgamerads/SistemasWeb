﻿using LIvroCaixa2023.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LivroCaixa2023.Tabelas{

    [Serializable]
    public class Usuario
    {
        public static List<Usuario> lista = new List<Usuario>();

        public static int idRaiz = 1;
        public int id { get; set; }
        public string login { get; private set; }
        public string password { get; private set; }
        public string nome { get; private set; }
        public char perfil { get; private set; }
        public string cpf { get; private set; }
        public Usuario(String login, String password, String nome, 
            char perfil, string cpf)
        {
            this.id = idRaiz++;
            this.login = login;
            this.password = password;
            this.nome = nome;
            this.perfil = perfil;
            this.cpf = cpf;
        }
        public Usuario(String login, String password)
        {
            this.id = idRaiz++;
            this.login = login;
            this.password = password;
            this.nome = login.ToUpper().Replace(".", " ");
            this.perfil = 'A';
        }

        public bool usuarioOk(Usuario u)
        {
            return this.login == u.login && this.password == u.password;
        }

        public static string montaTabela(String titulo, List<Usuario> lista) //  
        {

            Tabela tabela = new Tabela(lista.Count, 6, titulo);

            String[] titulos = { "Seq.", "Nome", "Login", "Senha", "Perfil", "CPF" };

            int i = 0;


            foreach (Usuario l in lista)
            {
                tabela.celula[i, 0] = l.id.ToString("D4");
                tabela.celula[i, 1] = l.nome;
                tabela.celula[i, 2] = l.login;
                tabela.celula[i, 3] = l.password == l.cpf ? l.cpf : "Já trocada";
                tabela.celula[i, 4] = l.perfil + "";
                tabela.celula[i, 5] = l.cpf;
                i++;
            }

            return tabela.tabela(titulos);
        }
    }



}