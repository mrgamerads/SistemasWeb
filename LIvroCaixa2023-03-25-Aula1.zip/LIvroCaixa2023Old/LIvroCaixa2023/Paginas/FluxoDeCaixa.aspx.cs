﻿using LivroCaixa2023.Classes;
using LivroCaixa2023.Tabelas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LIvroCaixa2023.Paginas
{
    public partial class FluxoDeCaixa : System.Web.UI.Page
    {

        private LivroCaixa livroCaixa = new LivroCaixa();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["usuario"] == null)
            {
                Response.Redirect("index.aspx", false);
                return;
            }           

            if (LivroCaixa.lancamentos != null && LivroCaixa.lancamentos.Count == 0)
            {
                LivroCaixa.lancamentos = Serializa.loadLancamento();
                if (LivroCaixa.lancamentos != null && LivroCaixa.lancamentos.Count > 0)
                {
                    LivroCaixa.lancamentos.Sort();
                    Lancamento.idRaiz = 
                        LivroCaixa.lancamentos[LivroCaixa.lancamentos.Count - 1].idLancamento;
                } 
                else
                {
                    LivroCaixa.lancamentos = new List<Lancamento>();
                }
            }

            tabLancamentos.Text = LivroCaixa.montaTabela("Lançamentos");

            inicializa();
        }

        private void inicializa()
        {
            lbCredito.Text = "Crédito";
            lbDebito.Text = "Débito";
            lbData.Text = "Data";
            lbDescricao.Text = "Descrição";
            lbValor.Text = "Valor";
            lbTipo.Text = "Tipo";
            btOk.Text = "OK";
        }

        protected void btOk_Click(object sender, EventArgs e)
        {
            // Validar todas as entradas
            // Instanciar um lançamento
            // Inserir o novo lancamento na lista de lançamentos
            // Mostrar a tabela de lançamentos atualizada
            // Salvar via serialização a lista nova

        }
          
    }
}