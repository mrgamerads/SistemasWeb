﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LivroCaixa2023.Tabelas{

    [Serializable]
    public class Usuario
    {
        private static int idRaiz = 1;
        public int id { get; set; }
        public string login { get; private set; }
        public string password { get; private set; }
        public string nome { get; private set; }
        public char perfil { get; private set; }
        public string cpf { get; private set; }
        public Usuario(String login, String password, String nome, 
            char perfil, string cpf)
        {
            this.id = idRaiz++;
            this.login = login;
            this.password = password;
            this.nome = nome;
            this.perfil = perfil;
            this.cpf = cpf;
        }
        public Usuario(String login, String password)
        {
            this.id = idRaiz++;
            this.login = login;
            this.password = password;
            this.nome = login.ToUpper().Replace(".", " ");
            this.perfil = 'A';
        }

        public bool usuarioOk(Usuario u)
        {
            return this.login == u.login && this.password == u.password;
        }
    }



}