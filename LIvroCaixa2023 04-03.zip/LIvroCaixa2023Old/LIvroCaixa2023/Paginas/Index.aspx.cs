﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LivroCaixa2023.Classes;
using LivroCaixa2023.Tabelas;

namespace LivroCaixa2023.Paginas
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            inicializa();

            List<Usuario> lista = new List<Usuario>();

            lista.Add(new Usuario("helio.rangel", "12345", "rangel", 'A', "32369280778"));
            lista.Add(new Usuario("ana.maria", "555555", "Maria", 'U', "12369280778"));
            lista.Add(new Usuario("carlos.augusto", "33333", "carlos", 'U', "22369280778"));
            lista.Add(new Usuario("manoel.jayme", "54321", "manoel", 'U', "42369280778"));
            lista.Add(new Usuario("nina.maria", "177777", "nina", 'U', "52369280778"));

            Serializa.save(lista);

           // lbUsuario.Text = "Achei nada não!";

            Usuario busca = new Usuario("carlos.augusto", "33333");

            foreach (Usuario usuario in lista)
            {
                if (usuario.usuarioOk(busca))
                {
                   // lbUsuario.Text = "Achei " + usuario.nome + ", ID:" + usuario.id;
                    break;
                }
            }
        }

        private void inicializa()
        {
            lbTitulo.Text = "Digite Login / Senha";
            lbLogin.Text = "Login";
            lbSenha.Text = "Senha";
        }
    }
}