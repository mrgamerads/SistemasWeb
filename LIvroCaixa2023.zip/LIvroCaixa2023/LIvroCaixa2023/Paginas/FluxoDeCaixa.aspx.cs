﻿using LivroCaixa2023.Classes;
using LivroCaixa2023.Tabelas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LIvroCaixa2023.Paginas
{
    public partial class FluxoDeCaixa : System.Web.UI.Page
    {
        private static LivroCaixa livroCaixaCorrente;

        private static List<LivroCaixa> listaLivro;
        protected void Page_Load(object sender, EventArgs e)
        {          

            if (listaLivro == null)
            {
                listaLivro = Serializa.loadLivroCaixa();
                if (listaLivro == null) // Isso só roda se a lista de Livros estiver zerada
                {
                    int mesCorrente = DateTime.Now.Month;
                    int anoCorrente = DateTime.Now.Year;

                    listaLivro = new List<LivroCaixa>();
                    livroCaixaCorrente = new LivroCaixa(0);
                    livroCaixaCorrente.ano = anoCorrente.ToString();
                    livroCaixaCorrente.mes = mesCorrente.ToString();
                    livroCaixaCorrente.stLivroFechado = false;                  
                    listaLivro.Add(livroCaixaCorrente);
                    Serializa.saveLivroCaixa(listaLivro);   
                }                
                listaLivro.Sort();                

                livroCaixaCorrente = listaLivro[listaLivro.Count-1];

                LivroCaixa.idRaiz = livroCaixaCorrente.idLivroCaixa + 1;
            }

            if (Session["usuario"] == null)
            {
                Response.Redirect("index.aspx", false);
                return;
            }          

            if (LivroCaixa.lancamentos != null && 
                LivroCaixa.lancamentos.Count == 0)
            {
                LivroCaixa.lancamentos = Serializa.loadLancamento();

                if (LivroCaixa.lancamentos != null && LivroCaixa.lancamentos.Count > 0)
                {
                    LivroCaixa.lancamentos.Sort();
                    Lancamento.idRaiz = 
                        LivroCaixa.lancamentos[LivroCaixa.lancamentos.Count - 1].idLancamento+1;
                } 
                else
                {
                    LivroCaixa.lancamentos = new List<Lancamento>();
                }
            }

            tabLancamentos.Text = LivroCaixa.montaTabela("Lançamentos do Mês " ,livroCaixaCorrente);

            inicializa();
            montaComboAno(comboAno);
            montaComboMes(comboMes);

            if (IsPostBack)
            {
                String evento = (this.Request["__EVENTTARGET"] == null) ? 
                    String.Empty : this.Request["__EVENTTARGET"];

                String resposta = (this.Request["__EVENTARGUMENT"] == null) ? 
                    String.Empty : this.Request["__EVENTARGUMENT"];

                if (resposta == "true" && evento == "fecharPeriodo")
                {
                    fechandoPeriodo();
                }
            }
        }

        private void inicializa()
        {
            lbCredito.Text = "Crédito";
            lbDebito.Text = "Débito";
            lbData.Text = "Data";
            lbDescricao.Text = "Descrição";
            lbValor.Text = "Valor";
            lbTipo.Text = "Tipo";
            btOk.Text = "OK";

            Usuario usuario = (Usuario)Session["usuario"];

            btVoltar.Visible = usuario.perfil == 'A';
            btSair.Visible = !btVoltar.Visible;
        }

        private void limpa()
        {
            mensagem.Text =
            txData.Text =
                txDescricao.Text =
                txValor.Text = String.Empty;

            rbCredito.Checked =
                rbDebito.Checked = false;

        }
        protected void btOk_Click(object sender, EventArgs e)
        {
            // TP de 25/03/2023

            // Validar todas as entradas do lançamento (uma a uma); 
            // Descrição não pode ser vazia
            // Valor não pode ser negativo nem inválido
            // Data deve ser válida e passada (não pode ser futura)
            // Crédito ou débito deve ser selecionado
            // Tem grana para o débito?
            // Instanciar um lançamento com os dados digitados;
            // Inserir o novo lançamento na lista de lançamentos;
            // Mostrar a tabela de lançamentos atualizada;
            // Salvar via serialização a lista nova (atualizada);
            // Limpar os campos do último lançamento recém inserido.
            // Formatar os valores com duas casas decimais

            double valor;

            if (!Double.TryParse(txValor.Text, out  valor))
            {
                mensagem.Text = "Valor digitado inválido";
                return;
            }

            if (valor < 0)
            {
                mensagem.Text = "Lançamento não pode ser negativo";
                return;
            }
            DateTime data;

            if (!DateTime.TryParse(txData.Text, out data))
            {
                mensagem.Text = "Data digitada é inválida!";
                return;
            }
            if (data.CompareTo(DateTime.Now) > 0)
            {
                mensagem.Text = 
                    "Data deve ser igual ou anterior a data atual!";
                return;
            }
            if (rbDebito.Checked)
            {
                double saldo = livroCaixaCorrente.pegaSaldo(livroCaixaCorrente);
                if (saldo < valor)
                {
                    mensagem.Text = "Saldo insuficiente!";
                    return;
                }
            }
            if (!rbCredito.Checked && !rbDebito.Checked)
            {
                mensagem.Text = "Selecione se crédito ou débito!";
                return;
            }
            if (txDescricao.Text.Trim() == string.Empty)
            {
                mensagem.Text = "Digite a descrição do lançamento!";
                return;
            }

            Lancamento l = new Lancamento(txDescricao.Text,
                livroCaixaCorrente.idLivroCaixa, // 1,
                valor,
                rbCredito.Checked ? 'C' : 'D',
                (Usuario)Session["usuario"], data);
            livroCaixaCorrente.add(l);
            tabLancamentos.Text = LivroCaixa.montaTabela("Lançamentos",livroCaixaCorrente);
            Serializa.saveLancamento(LivroCaixa.lancamentos);

            limpa();

        }

        protected void btSair_Click(object sender, EventArgs e)
        {
            Session.Clear();
            LivroCaixa.lancamentos.Clear();
            Usuario.lista.Clear();
            Response.Redirect("Index.aspx", false);
        }

        protected void btVoltar_Click(object sender, EventArgs e)
        {
            Response.Redirect("Index.aspx", false);
        }

        private void fechandoPeriodo()
        {
            return;
            livroCaixaCorrente.stLivroFechado = true;
            
            LivroCaixa novo = new LivroCaixa(livroCaixaCorrente.pegaSaldo(livroCaixaCorrente));
            int mes, ano;
            if (!int.TryParse(livroCaixaCorrente.ano, out ano) || ano == 0)
            {
                livroCaixaCorrente.ano = DateTime.Now.Year.ToString();
                ano = DateTime.Now.Year;
            }

            if (!int.TryParse(livroCaixaCorrente.mes, out mes) || mes == 0)
            {
                livroCaixaCorrente.mes = DateTime.Now.Month.ToString();
                mes = DateTime.Now.Month;
            }


            DateTime periodoAtual = new DateTime(ano, mes, 1);
            DateTime proximo = periodoAtual.AddMonths(1);
            novo.mes = proximo.Month + "";
            novo.ano = proximo.Year + "";
            listaLivro.Add(novo);
            listaLivro.Sort();
            livroCaixaCorrente = novo;
            Serializa.saveLivroCaixa(listaLivro);
            mensagem.Text = "Livro caixa fechado com sucesso!!!";
        }

        protected void btFechar_Click(object sender, EventArgs e)
        {
            messageBox(); 
        }        

        private void messageBox()
        {
            StringBuilder myScript = new StringBuilder(String.Empty);
            myScript.Append("<script type='text/javascript' language='javascript'> ");
            myScript.Append("var result = window.confirm('Confirma fechar o periodo " +
                "atual? Uma vez fechado não aceitará mais lançamentos!'); ");
            myScript.Append("__doPostBack('fecharPeriodo', result); ");
            myScript.Append("</script> ");
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "msg", myScript.ToString(), false);
        }

        private void montaComboMes(DropDownList combo)
        {
            if (combo.Items.Count > 0)
            {
                return;
            }

            String[] meses = { "","Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
                                  "Jul", "Ago", "Set", "Out", "Nov", "Dez", };

            for (int i = 1; i <= 12; i++) {

                ListItem item = new ListItem();
                item.Value = i.ToString();
                item.Text = meses[i];
                combo.Items.Add(item);
            }

            combo.SelectedValue = DateTime.Now.Month.ToString();
        }

        private void montaComboAno(DropDownList combo)
        {
            if (combo.Items.Count > 0)
            {
                return;
            }

            for (int i = DateTime.Now.Year-6; i <= DateTime.Now.Year; i++)
            {
                ListItem item = new ListItem();
                item.Text = i.ToString();
                item.Value = i.ToString();
                combo.Items.Add(item);
            }

            combo.SelectedValue = DateTime.Now.Year.ToString(); 
        }

        protected void btBusca_Click(object sender, EventArgs e)
        {
            foreach(LivroCaixa livro in listaLivro)
            {
                if (livro.mes == comboMes.SelectedValue && 
                    livro.ano == comboAno.SelectedValue)
                {
                    livroCaixaCorrente = livro;
                    return;
                }
                mensagem.Text = "Mes e Ano selecionado não encontrado na base!";
            }
        }
    }
}