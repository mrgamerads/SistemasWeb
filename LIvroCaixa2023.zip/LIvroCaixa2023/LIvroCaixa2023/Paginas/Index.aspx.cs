﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LivroCaixa2023.Classes;
using LivroCaixa2023.Tabelas;

namespace LivroCaixa2023.Paginas
{
    public partial class Index : System.Web.UI.Page
    {       
        protected void Page_Load(object sender, EventArgs e)
        {
            inicializa();

            String sair = Request.QueryString["sair"];

            if (sair == "sair")
            {              
                Session.Clear();
                txLogin.Text = txSenha.Text = "";
                Usuario.lista.Clear();
                LivroCaixa.lancamentos.Clear();               
                Response.Redirect("Index.aspx", false);
                return;
            }

            Usuario usuario = (Usuario)Session["usuario"];

            menu.Visible = usuario != null && usuario.perfil == 'A';

            if (Usuario.lista.Count == 0)
            {
                Usuario.lista = Serializa.loadUsuario();

                if (Usuario.lista != null)
                {
                    foreach (Usuario u in Usuario.lista)
                    {
                        Usuario.idRaiz = u.id > Usuario.idRaiz ? u.id : 
                            Usuario.idRaiz;
                    }

                 
                } 
                else
                {
                    lbMensagem.Text = "Lista vazia";
                }
            }           
        }

        private void inicializa()
        {
            lbTitulo.Text = "Digite Login / Senha";
            lbLogin.Text = "Login";
            lbSenha.Text = "Senha";
        }

        protected void btOk_Click(object sender, EventArgs e)
        {
            Usuario busca = new Usuario(
                txLogin.Text, 
                txSenha.Text
                );            

            foreach(Usuario u in Usuario.lista)
            {
                if (u.usuarioOk(busca))
                {
                    if (Usuario.validaCPF(txSenha.Text))
                    {
                        pnCadastraSenha.Visible = true;
                        menu.Visible = false;
                        Session["usuarioTroca"] = u;
                        return;
                    }

                    Session["usuario"] = u;
                    if (u.perfil == 'A')
                    {
                        menu.Visible = true;
                        return;
                    }
                    Response.Redirect("FluxoDeCaixa.aspx", false);
                    return;

                }
            }
          
            lbMensagem.Text = "Usuário não encontrado ou senha não confere!";
        }
        protected void btConfirmaSenha_Click(object sender, EventArgs e)
        {
          if (novaSenha1.Text.Trim().Equals(novaSenha2.Text.Trim()))
            {
                if (Usuario.validaCPF(novaSenha2.Text.Trim()))
                {
                    lbMensagem.Text = "Sua senha não pode ser um CPF válido";
                    return;                     
                }

                if (novaSenha2.Text.Trim().Length >= 6 && 
                    novaSenha2.Text.Trim().Length <= 8 )
                {                   

                    // char[] carac = novaSenha1.Text.Trim().ToCharArray();

                    //int cletraL = 0;
                    //int cletraH = 0;
                    //int cnum = 0;
                    //int especial = 0;

                    //foreach( char c in carac)
                    //{
                    //    if (c >= '0' && c <= '9') cnum++;
                    //    else
                    //    if (c >= 'a' && c <= 'z') cletraL++;
                    //    else
                    //    if (c >= 'A' && c <= 'Z') cletraH++;
                    //    else especial++;
                    //}

                  Usuario u = (Usuario)  Session["usuarioTroca"];
                    u.password = novaSenha2.Text.Trim();
                    Serializa.saveUsuario(Usuario.lista);
                    txSenha.Text = String.Empty;
                    menu.Visible = false;
                    pnCadastraSenha.Visible = false;
                } 
                else
                {
                    lbMensagem.Text = "Senha deve ter entre 6 e 8 dígitos";
                }
            } 
            else
            {
                lbMensagem.Text = "Senhas não conferem!";
            }  
        }

        protected void btCancela_Click(object sender, EventArgs e)
        {
            menu.Visible = 
            pnCadastraSenha.Visible = false;

            Session["usuario"] = 
            Session["usuarioTroca"] = null;

            lbMensagem.Text =
            novaSenha1.Text =
                novaSenha2.Text =
                txLogin.Text = 
                txSenha.Text = String.Empty;


        }
    }
}