﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LivroCaixa2023.Classes;
using LivroCaixa2023.Tabelas;

namespace LivroCaixa2023.Paginas
{
    public partial class Index : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
            inicializa();

            //Usuario.lista.Add(new Usuario("helio.rangel", "12345", "rangel", 'A', "32369280778"));
            ////lista.Add(new Usuario("ana.maria", "555555", "Maria", 'U', "12369280778"));
            ////lista.Add(new Usuario("carlos.augusto", "33333", "carlos", 'U', "22369280778"));
            ////lista.Add(new Usuario("manoel.jayme", "54321", "manoel", 'U', "42369280778"));
            ////lista.Add(new Usuario("nina.maria", "177777", "nina", 'U', "52369280778"));

            //Serializa.save(Usuario.lista);

            //return;

            if (Usuario.lista.Count == 0)
            {
                Usuario.lista = Serializa.loadUsuario();

                if (Usuario.lista != null)
                {
                    foreach (Usuario u in Usuario.lista)
                    {
                        Usuario.idRaiz = u.id > Usuario.idRaiz ? u.id : 
                            Usuario.idRaiz;
                    }

                   // Usuario.idRaiz++;
                } 
                else
                {
                    lbMensagem.Text = "Lista vazia";
                }
            }

           
        }

        private void inicializa()
        {
            lbTitulo.Text = "Digite Login / Senha";
            lbLogin.Text = "Login";
            lbSenha.Text = "Senha";
        }

        protected void btOk_Click(object sender, EventArgs e)
        {
            Usuario busca = new Usuario(txLogin.Text, txSenha.Text);

            foreach (Usuario usuario in Usuario.lista)
            {
                if (usuario.usuarioOk(busca))
                {
                    Session["usuario"] = usuario;

                    if (usuario.perfil == 'A')
                    {
                        menu.Visible = true;
                        return;
                    }
                    else
                    {
                        Response.Redirect("FluxoDeCaixa.aspx", false);
                        return;
                    }
                }
            }

            lbMensagem.Text = "Usuário não encontrado ou senha não confere!";
        }
    }
}