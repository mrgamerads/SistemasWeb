﻿using LivroCaixa2023.Classes;
using LivroCaixa2023.Tabelas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LIvroCaixa2023.Paginas
{
    public partial class FluxoDeCaixa : System.Web.UI.Page
    {

        private LivroCaixa livroCaixa = new LivroCaixa();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["usuario"] == null)
            {
                Response.Redirect("index.aspx", false);
                return;
            }          

            if (LivroCaixa.lancamentos != null && LivroCaixa.lancamentos.Count == 0)
            {
                LivroCaixa.lancamentos = Serializa.loadLancamento();

                if (LivroCaixa.lancamentos != null && LivroCaixa.lancamentos.Count > 0)
                {
                    LivroCaixa.lancamentos.Sort();
                    Lancamento.idRaiz = 
                        LivroCaixa.lancamentos[LivroCaixa.lancamentos.Count - 1].idLancamento+1;
                } 
                else
                {
                    LivroCaixa.lancamentos = new List<Lancamento>();
                }
            }

            tabLancamentos.Text = LivroCaixa.montaTabela("Lançamentos do Mes ");

            inicializa();
        }

        private void inicializa()
        {
            lbCredito.Text = "Crédito";
            lbDebito.Text = "Débito";
            lbData.Text = "Data";
            lbDescricao.Text = "Descrição";
            lbValor.Text = "Valor";
            lbTipo.Text = "Tipo";
            btOk.Text = "OK";
        }

        private void limpa()
        {
            mensagem.Text =
            txData.Text =
                txDescricao.Text =
                txValor.Text = String.Empty;

            rbCredito.Checked =
                rbDebito.Checked = false;

        }
        protected void btOk_Click(object sender, EventArgs e)
        {
            // TP de 25/03/2023

            // Validar todas as entradas do lançamento (uma a uma); 
            // Descrição não pode ser vazia
            // Valor não pode ser negativo nem inválido
            // Data deve ser válida e passada (não pode ser futura)
            // Crédito ou débito deve ser selecionado
            // Tem grana para o débito?
            // Instanciar um lançamento com os dados digitados;
            // Inserir o novo lançamento na lista de lançamentos;
            // Mostrar a tabela de lançamentos atualizada;
            // Salvar via serialização a lista nova (atualizada);
            // Limpar os campos do último lançamento recém inserido.
            // Formatar os valores com duas casas decimais

            double valor;

            if (!Double.TryParse(txValor.Text, out  valor))
            {
                mensagem.Text = "Valor digitado inválido";
                return;
            }

            if (valor < 0)
            {
                mensagem.Text = "Lançamento não pode ser negativo";
                return;
            }
            DateTime data;

            if (!DateTime.TryParse(txData.Text, out data))
            {
                mensagem.Text = "Data digitada é inválida!";
                return;
            }
            if (data.CompareTo(DateTime.Now) > 0)
            {
                mensagem.Text = 
                    "Data deve ser igual ou anterior a data atual!";
                return;
            }
            if (rbDebito.Checked)
            {
                double saldo = livroCaixa.pegaSaldo();
                if (saldo < valor)
                {
                    mensagem.Text = "Saldo insuficiente!";
                    return;
                }
            }
            if (!rbCredito.Checked && !rbDebito.Checked)
            {
                mensagem.Text = "Selecione se crédito ou débito!";
                return;
            }
            if (txDescricao.Text.Trim() == String.Empty)
            {
                mensagem.Text = "Digite a descrição do lançamento!";
                return;
            }

            Lancamento l = new Lancamento(txDescricao.Text,
                1,
                valor,
                rbCredito.Checked ? 'C' : 'D',
                (Usuario)Session["usuario"], data);
            livroCaixa.add(l);
            tabLancamentos.Text = LivroCaixa.montaTabela("Lançamentos");
            Serializa.saveLancamento(LivroCaixa.lancamentos);

            limpa();

        }
          
    }
}